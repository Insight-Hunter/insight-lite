# Insight Hunter Lite

AI-Powered Auto-CFO Platform for freelancers, small firms, and fractional CFOs.

## 🚀 Features

- **AI-Powered Financial Insights**: Automated analysis and recommendations
- **Interactive Dashboards**: Real-time financial metrics with Recharts
- **Cash Flow Forecasting**: AI-driven predictions for future periods
- **Automated Reporting**: Generate and export financial reports as PDFs
- **CSV Data Import**: Easy transaction upload from accounting software
- **PWA Support**: Install as a desktop/mobile app
- **Responsive Design**: Optimized for all devices

## 🛠️ Tech Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for blazing-fast builds
- **React Router** for navigation
- **Recharts** for data visualization
- **Tailwind CSS** for styling
- **jsPDF** for PDF generation
- **Lucide React** for icons

### Backend (100% Cloudflare)
- **Cloudflare Pages** - Static site hosting with global CDN
- **Cloudflare Workers** - Serverless API endpoints
- **Cloudflare D1** - SQL database
- **Cloudflare KV** - Key-value storage
- **Cloudflare R2** - Object storage for files/reports

## 📦 Installation

### Prerequisites

- Node.js 18+ and npm
- Cloudflare account (for deployment)
- Wrangler CLI: `npm install -g wrangler`

### Local Development

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd insight-hunter-lite
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Start development server**
   ```bash
   npm run dev
   ```

5. **Start Worker development server** (optional)
   ```bash
   npm run dev:worker
   ```

The app will be available at `http://localhost:5173`

## 🌐 Cloudflare Deployment

See [CLOUDFLARE_DEPLOYMENT.md](./CLOUDFLARE_DEPLOYMENT.md) for complete deployment instructions.

### Quick Deploy

1. **Login to Cloudflare**
   ```bash
   npm run cf:login
   ```

2. **Create resources**
   ```bash
   npm run cf:d1:create
   npm run cf:kv:create
   npm run cf:r2:create
   ```

3. **Update wrangler.toml** with your resource IDs

4. **Deploy**
   ```bash
   npm run deploy
   ```

## 📝 Available Scripts

### Development
- `npm run dev` - Start Vite dev server
- `npm run dev:worker` - Start Wrangler dev server for Workers

### Building
- `npm run build` - Build frontend for production
- `npm run build:worker` - Build Worker scripts

### Deployment
- `npm run deploy` - Deploy both frontend and backend
- `npm run deploy:pages` - Deploy frontend to Cloudflare Pages
- `npm run deploy:worker` - Deploy backend to Cloudflare Workers

### Utilities
- `npm run preview` - Preview production build locally
- `npm run lint` - Run ESLint

## 🗂️ Project Structure

```
insight-hunter-lite/
├── src/
│   ├── main.tsx              # App entry point
│   └── config/
│       └── api.ts            # API configuration
├── pages/                    # React pages/routes
│   ├── Login.tsx
│   ├── Dashboard.tsx
│   ├── Forecast.tsx
│   ├── Reports.tsx
│   └── ...
├── components/               # Reusable components
│   ├── ui/                   # UI components
│   └── Layout.tsx
├── workers/                  # Cloudflare Workers API
│   ├── index.ts             # Worker entry point
│   ├── router.ts            # API router
│   ├── api/                 # API endpoints
│   └── middleware/          # Middleware (CORS, auth)
├── functions/               # Cloudflare Pages Functions
│   └── api/
├── db/
│   └── schema.sql          # D1 database schema
├── public/
│   ├── _headers            # Cloudflare Pages headers
│   ├── _redirects          # Cloudflare Pages redirects
│   ├── manifest.json       # PWA manifest
│   └── sw.js               # Service worker
├── types/                  # TypeScript types
├── utils/                  # Utility functions
├── App.tsx                # Main app component
├── wrangler.toml          # Cloudflare Workers config
└── vite.config.ts         # Vite configuration
```

## 🔐 Environment Variables

Create a `.env` file based on `.env.example`:

```env
VITE_WORKER_URL=https://your-worker.workers.dev
VITE_ENABLE_AI_FEATURES=true
VITE_ENABLE_PDF_EXPORT=true
```

For Cloudflare Workers secrets:
```bash
wrangler secret put JWT_SECRET
wrangler secret put OPENAI_API_KEY
```

## 🔒 Security

- HTTPS enforced via Cloudflare
- Content Security Policy configured
- CORS properly configured
- JWT authentication for API
- SQL injection protection via D1 prepared statements
- XSS protection headers

## 📊 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/refresh` - Refresh token

### Transactions
- `GET /api/transactions` - List transactions
- `POST /api/transactions` - Create transaction
- `PUT /api/transactions/:id` - Update transaction
- `DELETE /api/transactions/:id` - Delete transaction
- `POST /api/transactions/upload` - Upload CSV

### Forecasts
- `GET /api/forecasts` - Get forecasts
- `POST /api/forecasts/generate` - Generate new forecast

### Reports
- `GET /api/reports` - List reports
- `POST /api/reports/generate` - Generate report

### AI
- `POST /api/ai/insights` - Get AI insights
- `POST /api/ai/analyze` - Analyze data
- `POST /api/ai/chat` - Chat with AI

## 🧪 Testing

```bash
# Run linter
npm run lint

# Type check
npx tsc --noEmit
```

## 📈 Performance

- **100/100 Lighthouse Score** target
- Global CDN via Cloudflare
- Edge computing with Workers
- Automatic asset optimization
- Brotli compression enabled

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with [React](https://react.dev/)
- Powered by [Cloudflare](https://cloudflare.com/)
- UI components inspired by [shadcn/ui](https://ui.shadcn.com/)
- Icons from [Lucide](https://lucide.dev/)

## 📞 Support

For issues and questions:
- Open an issue on GitHub
- Check [CLOUDFLARE_DEPLOYMENT.md](./CLOUDFLARE_DEPLOYMENT.md) for deployment help
- Visit [Cloudflare Community](https://community.cloudflare.com/)

---

**Note**: This application is designed for financial management and should not be used as the sole basis for financial decisions. Always consult with a qualified financial professional.
